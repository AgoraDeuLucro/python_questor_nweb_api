from setuptools import setup

with open("README.md", "r") as arq:
    readme = arq.read()

setup(name='py_questor_nweb',
    version='0.0.5',
    license='MIT License',
    author='Yuri Gomes',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='yuri.gomes@grupobpo.com.br',
    keywords='questor, nweb',
    description=u'Wrapper não oficial do Questor nWeb',
    packages=['py_questor_nweb'],
    install_requires=['requests'],)